import { StudentFilterPipe } from './student-filter.pipe';

describe('StudentFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new StudentFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
