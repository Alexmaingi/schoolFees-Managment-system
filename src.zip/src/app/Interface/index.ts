export interface Students {
  id: number;
  name: string;
  feesBalance: number;
}
