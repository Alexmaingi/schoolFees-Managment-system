import { BalanceColorDirective } from './balance-color.directive';

describe('BalanceColorDirective', () => {
  it('should create an instance', () => {
    const directive = new BalanceColorDirective();
    expect(directive).toBeTruthy();
  });
});
